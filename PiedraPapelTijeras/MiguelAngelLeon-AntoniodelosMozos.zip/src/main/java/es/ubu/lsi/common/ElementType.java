package es.ubu.lsi.common;


/**
 * Element type.
 * 
 * @author Mario Erro
 */
public enum ElementType {
	PIEDRA,
	PAPEL,
	TIJERA,
	LOGOUT, 
	SHUTDOWN;
}
